import UIKit

class WordsTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    
    vocabController.createVocabularyWord()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vocabController.vocabWords.count
}
   
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WordsCell", for: indexPath)
        
        let vocabWord = vocabController.vocabWords[indexPath.row]
        
        cell.textLabel?.text = "\(vocabWord.word)"
        
        return cell
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowDefinition" {
            guard let detailVC = segue.destination as? DefinitionViewController,
            let indexPath = tableView.indexPathForSelectedRow else { return }
            detailVC.vocabWord = vocabController.vocabWords[indexPath.row]
            
           
            }
        }
    
   

    
    
    
    
    
    
    
    }
    
  let vocabController = VocabularyController()


