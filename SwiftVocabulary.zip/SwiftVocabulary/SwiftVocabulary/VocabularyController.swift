import Foundation

class VocabularyController {

var vocabWords: [VocabularyWord] = []

func createVocabularyWord() {
    vocabWords.append(VocabularyWord(word: "Water", definition: "Definition of water"))
    vocabWords.append(VocabularyWord(word: "Fire", definition: "Definition of fire"))
    }
}
