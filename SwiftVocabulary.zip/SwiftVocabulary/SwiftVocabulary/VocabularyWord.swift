//
//  VocabularyWord.swift
//  SwiftVocabulary
//
//  Created by Lambda_School_Loaner_64 on 4/29/19.
//  Copyright © 2019 Lambda. All rights reserved.
//

import Foundation

struct VocabularyWord {
    
    let word: String
    let definition: String
    
    init(word: String, definition: String) {
        self.word = word
        self.definition = definition
    }
}
