import UIKit

class DefinitionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
    func updateViews() {
        guard isViewLoaded else { return }
        
        if let word = vocabWord?.word,
            let definition = vocabWord?.definition {
            wordLabel.text = word
            definitionText.text = definition
    }
}
    
    var vocabWord: VocabularyWord? {
        didSet {
            updateViews()
        }
    }
    
    @IBOutlet var wordLabel: UILabel!
    @IBOutlet var definitionText: UITextView!
}

    

